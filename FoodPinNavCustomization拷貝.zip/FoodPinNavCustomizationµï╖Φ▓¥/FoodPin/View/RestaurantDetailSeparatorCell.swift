//
//  RestaurantDetailSeparatorCell.swift
//  FoodPin
//
//  Created by My Mac on 2020/2/19.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import UIKit

class RestaurantDetailSeparatorCell: UITableViewCell {
    
    @IBOutlet var titleLabel:UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
